cat non_existent_file.txt 2> error.log
