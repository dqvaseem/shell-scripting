#!/bin/bash



ls
pwd
#!/bin/bash



ls
pwd

whoami
ls -l
uname
uname -r
