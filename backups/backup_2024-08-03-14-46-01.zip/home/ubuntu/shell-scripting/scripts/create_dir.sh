mkdir /tmp/mydir
if [ $? -ne 0 ]; then
	    echo "Failed to create directory /tmp/mydir"
fi
