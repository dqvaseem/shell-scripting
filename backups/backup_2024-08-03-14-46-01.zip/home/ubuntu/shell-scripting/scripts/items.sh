for item in item1 item2 item3; do
	    echo "Current item is: $item"
    done
