i=10
while [ $i -ge 0 ]
do 
    echo "Reverse order $i "
     let i--
done
